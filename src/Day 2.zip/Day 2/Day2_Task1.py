# -*- coding: utf-8 -*-
"""
Created on Tue Feb  3 11:39:16 2026

@author: DELL
"""

name = input("Enter the name:")
age = int(input("Enter the age:"))
newage = age + 4
print(f"Hey {name}, you will be {newage} years old in 2030!")
