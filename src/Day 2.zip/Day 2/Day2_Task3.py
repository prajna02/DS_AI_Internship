# -*- coding: utf-8 -*-
"""
Created on Tue Feb  3 12:01:49 2026

@author: DELL
"""

item_name = "Laptop"
quantity = 14
price = 67000
in_stock = True
print(f"Item:{item_name}, Qty:{quantity}, Price:{price}, Available:{in_stock}")
total_cost= quantity*price
print("Total Cost:", total_cost)


